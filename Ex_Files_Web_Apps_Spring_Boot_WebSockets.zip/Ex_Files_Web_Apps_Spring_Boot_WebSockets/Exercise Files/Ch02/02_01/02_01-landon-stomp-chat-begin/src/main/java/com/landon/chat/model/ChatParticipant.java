package com.landon.chat.model;

public class ChatParticipant {
	
}
