package com.landon.chat.model;

import java.util.Date;

public class ChatOutMessage {
	
	
}
